<?php

namespace App\Http\Controllers;

use App\Models\ApplyJob;
use App\Models\Job;
use App\Models\Region;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class JobController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $regions = Region::all();
        return view('AddJobs', compact('regions'));
    }

    public function jobs_list()
    {
        $jobs = Job::all();
        $jobs = Job::orderBy('CompanyName')->paginate(5)->withQueryString();
        return view('/jobs', compact('jobs'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $user = Auth::user()->id;

        $request->validate([
            'CompanyName' => 'required|unique:jobs',
            'JobCategory' => 'required|min:5|max:255',
            'description' => 'required',
            'Age' => 'required',
            'Gender' => 'required',
            'region' => 'required',
            'image' => 'required|image|mimes:jpeg,png,jpg|max:2048',
        ]);

        $image = $request->image;
        $imageName = date('HiSd') . '-' . $image->getClientOriginalName();

        $job = new Job();
        $job->CompanyName = $request->CompanyName;
        $job->JobCategory = $request->JobCategory;
        $job->Description = $request->description;
        $job->Age = $request->Age;
        $job->Gender = $request->Gender;
        $job->Image = $imageName;
        $job->region_id = $request->region;
        $job->user_id = $user;

        $image->move(public_path() . '/images/JobsImage', $imageName);
        $job->save();

        return redirect()->back()->with('success', 'Your data has been added');
    }

    public function ShowJobDetail(Job $Job)
    {
        $user = Auth::user()->id;
        $applys = ApplyJob::where('user_id', $user)->where('job_id', $Job->id)->get();
        if ($applys->count() > 0) {
            foreach ($applys as $apply) {
                $apply_job = $apply->job_id;
            }
        } else {
            $apply_job = null;
        }
        return view('JobDetail', compact('Job', 'apply_job'));
    }

    public function ApplyJob(Job $job)
    {

        $user = Auth::user()->id;
        $ApplyJob = new ApplyJob();

        $ApplyJob->user_id = $user;
        $ApplyJob->job_id = $job->id;

        $ApplyJob->save();

        return redirect("/notifications");
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    public function showUpdate($id)
    {
        $regions = Region::all();
        $job = Job::find($id);
        return view('Update_job', compact('job', 'regions'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    public function cancel($apply)
    {
        ApplyJob::destroy($apply);
        return redirect('notifications');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $user = Auth::user()->id;
        $request->validate([
            'CompanyName' => 'required|unique:jobs,CompanyName,' . $id,
            'JobCategory' => 'required|min:5|max:255',
            'description' => 'required',
            'Age' => 'required',
            'Gender' => 'required',
            'region' => 'required',
            'image' => 'image|mimes:jpeg,png,jpg|max:2048',
        ]);

        $data = [
            'CompanyName' => $request->CompanyName,
            'JobCategory' => $request->JobCategory,
            'Description' => $request->description,
            'Age' => $request->Age,
            'Gender' => $request->Gender,
            'region_id' => $request->region,
            'user_id' => $user
        ];

        if ($request->image) {
            $image = $request->image;
            $imageName = date('HiSd') . '-' . $image->getClientOriginalName();
            $data['Image'] = $imageName;
            $image->move(public_path() . 'images/JobsImage/', $imageName);
        }

        Job::find($id)->update($data);

        return redirect('home')->with('success', 'Your data has been updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $job = Job::find($id);

        if ($job) {
            $job->delete();
        }

        return redirect('home')->with('success', 'Your data has been deleted');
    }
}

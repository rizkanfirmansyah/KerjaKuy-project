<link href="<?php echo e(asset('/css/style.css')); ?>" rel="stylesheet">

<style>
@import  url('https://fonts.googleapis.com/css2?family=Raleway:wght@200;300;400&display=swap');
</style>




<?php $__env->startSection('content'); ?>

<div class="col">
    <div class="row-sm">

    </div>

    <div class="row-sm d-flex justify-content-center">
    <div class="card" style="width: 35rem; height: 45rem;">
    <h2 class ="header-text-2 d-flex justify-content-center mt-2">Complete your Profile</h2><br>
    <?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <img class="card-img-top" src="<?php echo e(asset('image/' .$profile->image)); ?>" alt="Card image cap">
  <div class="card-body">
    <p class="card-text">Name : <?php echo e($user->name); ?><br></p>
    <p class="card-text">Username : <?php echo e($profile->username); ?><br></p> 
    <p class="card-text">Email : <?php echo e($user->email); ?><br></p> 
    <p class="card-text">Phone Number : <?php echo e($profile->phone_number); ?><br></p> 
  </div>
</div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="row">

    </div>
    <div class="container d-flex justify-content-center mt-5">
    <form action="<?php echo e(url('/profile')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Full name</label>
            <input type="text" name="fullName" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" style ="width : 30 rem;" required>
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Phone number</label>
            <input type="text" name="PhoneNumber" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" style ="width : 30 rem;" required>
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Region</label>
            <div class="input-group mb-3" style ="width : 30rem;" required>
              <select class="form-select" id="inputGroupSelect01" name="region">  
                <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value= "<?php echo e($region->id); ?>" ><?php echo e($region->city); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">CV link</label>
            <input type="text" name="CVLink" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" style ="width : 30 rem;" required>
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Image</label>
            <div class="input-group" style ="width : 30rem;">
              <input type="file" name="image" enctype="multipart/form-data" class="form-control" id="inputGroupFile04" aria-describedby="inputGroupFileAddon04" aria-label="Upload" required>
            </div>
        </div>
        <center>
        <button type="submit" value="Add" class="bttn-warning bttn-jelly bttn-sm mt-5"  style ="width : 100px; height: 35px;">Update</button>
        </center>
    </form>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Binus\Skripsi\File Coding\13 Mei 2022\KerjaKuy\KerjaKuy\resources\views//profile_after_login.blade.php ENDPATH**/ ?>
<link href="<?php echo e(asset('/css/style.css')); ?>" rel="stylesheet">




<?php $__env->startSection('content'); ?>
<div class="container">
    <center>
  <div class="row">
    <div class="col-sm">
      
    </div>
    <div class="col-sm">
      <br><br><br>
      <h2>Search Vacancy</h2>
      <br>
      <form>
  <div class="form-group">
    <input type="text" class="form-control" placeholder="Search for jobs, company">
  </div>
  <div class="form-group">
    <input type="text" class="form-control" placeholder="Region">
  </div>
  <div class="form-group">
  <input type="text" class="form-control" placeholder="Specialization">
  </div>
  <br>
  <button type="submit" class="btn-orange">Search</button>
</form>
    </div>
    <div class="col-sm">
      
    </div>
  </div>

  <br><br><br>
      <h2>Reccomended For You</h2>
</center>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ryan Christian\OneDrive\Desktop\KerjaKuy\resources\views/home.blade.php ENDPATH**/ ?>
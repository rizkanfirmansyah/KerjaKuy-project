

<?php $__env->startSection('content'); ?>
<div class="container">
    <form action="<?php echo e(url('Addjob')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Company Name :</label>
            <input type="text" name="CompanyName" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Job Category :</label>
            <input type="text" name="JobCategory" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Description : </label>
            <textarea class="form-control" name="description" placeholder="Tambahkan deskripsi" id="floatingTextarea"  value="<?php echo e(old('description')); ?>" required></textarea>
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Age :</label>
            <input type="number" name="Age" min="1" max="100" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Gender :</label><br>
            <input type="radio" name="Gender" value="M" required>
            <label for="M">Male</label><br>
            <input type="radio" name="Gender"  value="F">
            <label for="F">Female</label><br>
            <input type="radio" name="Gender"  value="M&F">
            <label for="M&F">Male & Female</label><br>
        </div>
        <div>
            <label for="exampleInputEmail1" class="form-label">Image :</label><br>
            <input type="file" name="image" enctype="multipart/form-data" required>   
        </div>
        <br>
        <button type="submit" value="Add" class="btn btn-primary">Submit</button>
        <button type="reset" value="Reset" class="btn btn-warning">Reset</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Binus\Skripsi\File Coding\31 Mei 2022\KerjaKuy\KerjaKuy\resources\views/AddJobs.blade.php ENDPATH**/ ?>
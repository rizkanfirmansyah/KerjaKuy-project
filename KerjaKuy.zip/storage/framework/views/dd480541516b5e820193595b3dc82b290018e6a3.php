<link href="<?php echo e(asset('/css/style.css')); ?>" rel="stylesheet">




<?php $__env->startSection('content'); ?>
<div class="container">
    <form action="<?php echo e(url('UpdateProfile')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Username</label>
            <input type="text" name="CompanyName" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">full name</label>
            <input type="text" name="JobCategory" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Email</label>
            <input type="text" name="JobCategory" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Phone number</label>
            <input type="text" name="JobCategory" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Attachment</label>
            <input type="text" name="JobCategory" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
        </div>
        <label for="exampleInputEmail1" class="form-label">Image</label>
        <br>
        <input type="file" name="image" enctype="multipart/form-data">
        <br>
        <br>
        <button type="submit" value="Add" class="btn btn-primary">Update</button>
    </form>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\KerjaKuy\resources\views//Update_profile.blade.php ENDPATH**/ ?>
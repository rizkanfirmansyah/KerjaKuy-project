<link href="<?php echo e(asset('/css/style.css')); ?>" rel="stylesheet">

<style>
@import  url('https://fonts.googleapis.com/css2?family=Raleway:wght@200;300;400&display=swap');
</style>



<?php $__env->startSection('content'); ?>
<div class="container">
    <center>
  <div class="row">
    <div class="col-sm">
    </div>
    <div class="col-sm">
      <br><br><br>
      <h2 class = "header-text">Search Vacancy</h2>
      <br>
      <form>
  <div class="form-group">
    <input type="text" class="form-control" placeholder="Search for jobs, company">
    <br>
  </div>
  <div class="form-group">
    <input type="text" class="form-control" placeholder="Region">
    <br>
  </div>
  <div class="form-group">
  <input type="text" class="form-control" placeholder="Specialization">
  <br>
  </div>
  <br>
  <button type="submit" class="btn-orange">Search</button>

    <a href="<?php echo e(url('add')); ?>">
        <button type="button" class="btn-add-job">Add Job</button>
    </a>
</form>
    </div>
    <div class="col-sm">
    </div>
  </div>


<div class="row ml-5">
      <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="d-flex justify-content-center" style ="margin-left : 25px" data-aos="fade-up" data-aos-duration = "2000" data-aos-delay="100"> 
                <div class="card mt-3 ml-5" style="width: 15rem; height: 25rem;">
                    <a href="<?php echo e(url('Job_detail/ ' . $job->id)); ?>">
                      <img src="<?php echo e(asset('images/JobsImage/' . $job->Image)); ?>" class="card-img-top" style="height:250px; widht:350px; align:left;float: left;" >
                    </a>
                    <div class="card-body" style="align:right">
                        <p class="card-text"><?php echo e($job->CompanyName); ?></p>
                        <p class="card-text"><?php echo e($job->JobCategory); ?></p>
                    </div>                   
                </div> 
        </div> 
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
</div>




</center>
<br><br><br>
<div class ="d-flex justify-content-center">
    <?php echo e($jobs->links()); ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Binus\Skripsi\File Coding\11 Mei 2022\KerjaKuy\KerjaKuy\resources\views//jobs.blade.php ENDPATH**/ ?>
<link href="<?php echo e(asset('/css/style.css')); ?>" rel="stylesheet">



<style>
@import  url('https://fonts.googleapis.com/css2?family=Raleway:wght@200;300;400&display=swap');
</style>

<?php $__env->startSection('content'); ?>
<div class="container">
    <?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card" style="width: 18rem;">
            <img src="..." class="card-img-top" alt="...">
            <div class="card-body">
                <p class="card-text">Username : <?php echo e($profile->username); ?><br></p> 
                <p class="card-text">Email : <?php echo e($profile->email); ?><br></p> 
                <p class="card-text">Phone Number : <?php echo e($profile->phone_number); ?><br></p> 
                <p class="card-text">CV Link : <?php echo e($profile->attachment); ?><br></p>
            </div>
        </div>
        <?php $__currentLoopData = $applys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!-- Button trigger modal -->
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
            Accept
        </button>

        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Comment</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form action="<?php echo e(url('notification_detail/ ' .$apply->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="modal-body">
                            <div class="mb-3">
                                <textarea class="form-control" name="description" placeholder="Comment" id="floatingTextarea"  value="<?php echo e(old('description')); ?>"></textarea>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" value="Add" class="btn btn-primary d-flex justify-content-end">Send</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <form action="<?php echo e(url('notification_detail/ ' .$apply->id)); ?>" method="post">
            <?php echo method_field('delete'); ?>
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-danger ml-2">Reject</button>
        </form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TestLaravel\KerjaKuy\resources\views//notification_detail.blade.php ENDPATH**/ ?>
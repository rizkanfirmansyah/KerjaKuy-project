<link href="<?php echo e(asset('/css/style.css')); ?>" rel="stylesheet">




<?php $__env->startSection('content'); ?>
<div class="container">
    <center>
  <div class="row">
    <div class="col-sm">
      
    </div>
    <div class="col-sm">
      <br><br>
      <h2>Notifications Center</h2>
      <br>
      <form>
  <div class="form-group">
    <input type="text" class="form-control" placeholder="Search for applied jobs, company">
  </div>
  <br>
  <button type="submit" class="btn-orange">Search</button>
</form>
    </div>
    <div class="col-sm">
    </div>
  </div>

  <br><br><br>

</center>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projek Laravel\KerjaKuy\resources\views/notifications.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
<div class="container">
    <form action="<?php echo e(url('Update_job/ ' .$Job)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo method_field('patch'); ?>
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Company Name :</label>
            <input type="text" name="CompanyName" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e(old('jobs.CompanyName')); ?>" required>
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Job Category :</label>
            <input type="text" name="JobCategory" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Description : </label>
            <textarea class="form-control" name="description" placeholder="Tambahkan deskripsi" id="floatingTextarea"  value="<?php echo e(old('description')); ?>" required></textarea>
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Age :</label>
            <input type="number" name="Age" min="1" max="100" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Region</label>
            <div class="input-group mb-3" style ="width : 30rem;" required>
              <select class="form-select" id="inputGroupSelect01" name="region">  
                <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value= "<?php echo e($region->id); ?>" ><?php echo e($region->city); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Gender</label>
            <div class="input-group mb-3" style ="width : 30rem;" required>
              <select class="form-select" id="inputGroupSelect01" name="Gender">  
                    <option value="M">Male</option>
                    <option value="F">Female</option>
                    <option value="M&F">Male & Female</option>
              </select>
            </div>
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Image</label>
            <div class="input-group" style ="width : 30rem;">
              <input type="file" name="image" enctype="multipart/form-data" class="form-control" id="inputGroupFile04" aria-describedby="inputGroupFileAddon04" aria-label="Upload" required>
            </div>
        </div>
        <br>
        <button type="submit" value="Add" class="btn btn-primary">Submit</button>
        <button type="reset" value="Reset" class="btn btn-warning">Reset</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Binus\Skripsi\File Coding\17 Juni 2022\KerjaKuy\KerjaKuy\resources\views/Update_job.blade.php ENDPATH**/ ?>
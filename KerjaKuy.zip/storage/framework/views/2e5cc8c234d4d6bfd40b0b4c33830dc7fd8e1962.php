<link href="<?php echo e(asset('/css/style.css')); ?>" rel="stylesheet">

<style>
    @import  url('https://fonts.googleapis.com/css2?family=Raleway:wght@200;300;400&display=swap');
</style>




<?php $__env->startSection('content'); ?>
    <div class ="container-fluid"
        style="background-image: url('images/JobsImage/background_search.jpg');
height : 600px; width :100%; background-size: cover;"
        data-aos="fade-in" data-aos-duration ="1500">
        <div class="background">
            <div class="container d-flex justify-content-center;">
            </div>
            <?php if(\Session::has('success')): ?>
                <div id="SweetAlert" data-message="<?php echo e(\Session::get('success')); ?>">
                </div>
            <?php endif; ?>

            <center>
                <div class="row">
                    <div class="col-sm">
                    </div>
                    <div class="col-sm">
                        <div class ="search-container">
                            <br><br><br>
                            <h2 class="header-text-2 mt-5">Search Vacancy</h2>
                            <br>
                            <form action="/home">
                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Search for jobs, company" name
                                        ="searchCompanyName" style =" height : 40px; width :1000px">
                                    <br>
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Specialization" name
                                        ="searchSp" style =" height : 40px; width :1000px">
                                    <br>
                                </div>
                                <div class="mb-3">
                                    <div class="input-group mb-3" style =" height : 40px; width :1000px">
                                        <select class="form-select" id="inputGroupSelect01" name="region" required>
                                            <option value ="" selected>Region</option>
                                            <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($region->id); ?>"><?php echo e($region->city); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <button type="submit" class="bttn-warning bttn-jelly bttn-sm mt-5" style
                                    ="width : 100px; height: 35px;">Search</button>
                            </form>
                        </div>
                    </div>

                    <div class="col-sm">
                    </div>
                </div>
                <br><br><br>
                <br><br><br>
                <br><br><br>
                <br><br><br>
                <?php if($request->has('searchCompanyName') && $request->searchCompanyName != ''): ?>
                    <h2 class ="header-text-2" data-aos ="fade-in">Jobs result</h2>
                    <br><br>
                <?php elseif($request->has('region') && $request->region != ''): ?>
                    <h2 class ="header-text-2" data-aos ="fade-in">Jobs result</h2>
                    <br><br>
                <?php elseif($request->has('searchSp') && $request->searchSp != ''): ?>
                    <h2 class ="header-text-2" data-aos ="fade-in">Jobs result</h2>
                    <br><br>
                <?php else: ?>
                    <h2 class ="header-text-2" data-aos ="fade-in">Popular Vacancy</h2>
                    <br><br>
                <?php endif; ?>

                <div class="row ml-5 justify-content-center">
                    <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex justify-content-center">
                            <div class="card mt-3 ml-5" style="width: 15rem; height: 25rem; margin-right : 20px;"
                                data-aos="fade-up" data-aos-duration="1000" data-aos-delay="100">
                                <a href="<?php echo e(url('Job_detail/' . $job->id)); ?>" class="hvr-shrink">
                                    <img src="<?php echo e(asset('images/JobsImage/' . $job->Image)); ?>" class="card-img-top"
                                        style="height:250px;">
                                </a>
                                <div class="card-body">
                                    <p class="card-text"><?php echo e($job->CompanyName); ?></p>
                                    <p class="card-text"><?php echo e($job->JobCategory); ?></p>
                                    <p class="card-text"><?php echo e($job->province); ?></p>
                                </div>
                            </div>
                            <div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
        </div>
    </div>
    </center>

    <br><br>



    <div class ="d-flex justify-content-center">
        
    </div>



    <br><br>
    <br><br><br><br>
    <br><br>


    <div class ="d-flex justify-content-center">
        <h2 class="header-text-2" data-aos="fade-in" data-aos-duration ="1500">Jobs in your region</h2>
        <br><br><br>
    </div>

    <center>
        <div class="row ml-5 justify-content-center">
            <?php $__currentLoopData = $recJobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recJob): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="d-flex justify-content-center">
                    <div class="card mt-3 ml-5" style="width: 15rem; height: 25rem; margin-right : 20px;" data-aos="fade-up"
                        data-aos-duration="1000" data-aos-delay="100">
                        <a href="<?php echo e(url('Job_detail/ ' . $recJob->id)); ?>" class="hvr-shrink">
                            <img src="<?php echo e(asset('images/JobsImage/' . $recJob->Image)); ?>" class="card-img-top"
                                style="height:250px;">
                        </a>
                        <div class="card-body">
                            <p class="card-text"><?php echo e($recJob->CompanyName); ?></p>
                            <p class="card-text"><?php echo e($recJob->JobCategory); ?></p>
                        </div>
                    </div>
                    <div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        </div>
        <br><br>
    </center>

    <div class ="d-flex justify-content-center">
        
    </div>
    </div>


    <div class="row">
        <div class="col">

        </div>
        <div class="col">

        </div>

        <div class="col">

        </div>
    </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rizkan/Applications/Project/KerjaKuy/resources/views//home.blade.php ENDPATH**/ ?>
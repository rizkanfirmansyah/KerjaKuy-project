<link href="<?php echo e(asset('/css/style.css')); ?>" rel="stylesheet">



<?php $__env->startSection('content'); ?>
<div class="container">
    <center>
  <div class="row">
    <div class="col-sm">
      
    </div>
    <div class="col-sm">
      <br><br><br>
      <h2>Search Vacancy</h2>
      <br>
      <form>
  <div class="form-group">
    <input type="text" class="form-control" placeholder="Search for jobs, company">
  </div>
  <div class="form-group">
    <input type="text" class="form-control" placeholder="Region">
  </div>
  <div class="form-group">
  <input type="text" class="form-control" placeholder="Specialization">
  </div>
  <br>
  <button type="submit" class="btn-orange">Search</button>
</form>
    </div>
    <div class="col-sm">
      
    </div>
  </div>

  <br><br><br>

<div class=container>
    <a href="<?php echo e(url('add')); ?>">
        <button type="button" class="btn btn-success">Add Job</button>
    </a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Skripsi\KerjaKuy\resources\views/jobs.blade.php ENDPATH**/ ?>
<link href="<?php echo e(asset('/css/style.css')); ?>" rel="stylesheet">



<style>
@import  url('https://fonts.googleapis.com/css2?family=Raleway:wght@200;300;400&display=swap');
</style>

<?php $__env->startSection('content'); ?>
<div class="container">
    <center>
  <div class="row">
    <div class="col-sm">
      
    </div>
    <div class="col-sm">
      <br><br>
      <h2 class = "header-text-2">Notifications Center</h2>
      <br>
      <form>
  <div class="form-group">
    <input type="text" class="form-control" placeholder="Search for applied jobs, company">
  </div>
  <br>
  <button type="submit" class="btn-orange">Search</button>
</form>
    </div>
    <div class="col-sm">
    </div>
  </div>

  <br><br><br>

  <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="card">
      <div class="card-body">
          
        <p>User Id : <?php echo e($notification->user_id); ?></p>
        <br>
        <p>Name : <?php echo e($notification->name); ?></p>
        <br>
        <p>Email : <?php echo e($notification->email); ?></p>
        <br>
        <p>Status : <?php echo e($notification->status); ?></p>
        <br>
        <p>Company: <?php echo e($notification->CompanyName); ?></p>
        <br>
        <p>Job desk : <?php echo e($notification->JobCategory); ?></p>
      </div>
  </div>
  <br>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  <?php $__currentLoopData = $applys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="card">
      <div class="card-body">
        <p>Company: <?php echo e($apply->CompanyName); ?></p>
        <br>
        <p>Job desk : <?php echo e($apply->JobCategory); ?></p>
        <br>
        <p>Status : <?php echo e($apply->status); ?></p>
      </div>
  </div>
  <br>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</center>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Binus\Skripsi\File Coding\11 Mei 2022\KerjaKuy\KerjaKuy\resources\views//notifications.blade.php ENDPATH**/ ?>
<link href="<?php echo e(asset('/css/style.css')); ?>" rel="stylesheet">

<style>
@import  url('https://fonts.googleapis.com/css2?family=Raleway:wght@200;300;400&display=swap');
</style>



<?php $__env->startSection('content'); ?>
<div class="container d-flex justify-content-center">
<div class="card mb-3" style="max-width: 540px; max-height: 700px">
  <div class="row g-0">
    <div class="col-md-4">
      <img src="<?php echo e(asset('images/JobsImage/' . $Job->Image)); ?>" class="img-fluid rounded-start" alt="...">
    </div>
    <div class="col-md-8">
      <div class="card-body">
        <h5 class="card-title"><?php echo e($Job->CompanyName); ?></h5>
        <p class="card-text"><?php echo e($Job->JobCategory); ?></p>
        <p class="card-text"><small class="text-muted"><?php echo e($Job->Description); ?></small></p>
     
        <p class="card-text"><small class="text-muted"> Umur(Minimal): <?php echo e($Job->Age); ?></p>
        <p class="card-text"><small class="text-muted"> Gender : <?php echo e($Job->Gender); ?></p>
        <form action="<?php echo e($Job->id); ?>" method="post">
            <?php echo csrf_field(); ?>
            <button type="submit" value="Add" class="btn-orange">Apply</button>
        </form>
      </div>
    </div>
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\KerjaKuy\resources\views/JobDetail.blade.php ENDPATH**/ ?>
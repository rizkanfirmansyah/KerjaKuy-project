<link href="<?php echo e(asset('/css/style.css')); ?>" rel="stylesheet">



<style>
@import  url('https://fonts.googleapis.com/css2?family=Raleway:wght@200;300;400&display=swap');
</style>

<?php $__env->startSection('content'); ?>


<div class="col">
    <div class="row-sm d-flex justify-content-center">

    </div>

    <div class="row-sm d-flex justify-content-center">
    <div class="card" style="width: 30rem; height: 30rem;">
    <h2 class ="header-text-2 d-flex justify-content-center">Profile Settings</h2><br>
  <img class="card-img-top" src="asset()" alt="Card image cap">
  <div class="card-body">
    <p class="card-text">Name : <?php echo e($user->name); ?><br></p>
    <p class="card-text">Email : <?php echo e($user->email); ?><br></p>
    <form>
  <div class="form-group">
    <label for="exampleFormControlFile1">Attach your CV, or Sertification</label>
    <input type="file" class="form-control-file" id="exampleFormControlFile1">
  </div>
</form>
  </div>
</div>
    </div>

    <div class="row">

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Binus\Skripsi\File Coding\11 Mei 2022\KerjaKuy\KerjaKuy\resources\views//profile.blade.php ENDPATH**/ ?>
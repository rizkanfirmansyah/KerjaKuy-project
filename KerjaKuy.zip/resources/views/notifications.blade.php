<link href="{{ asset('/css/style.css') }}" rel="stylesheet">

@extends('layouts.app')

<style>
@import url('https://fonts.googleapis.com/css2?family=Raleway:wght@200;300;400&display=swap');
</style>

@section('content')
<div class="container">
    <center>
  <div class="row">
    <div class="col-sm">
    </div>
    <div class="col-sm">
      <br><br>
      <h2 class = "header-text-2">Notifications Center</h2>
      <br>
    </div>
    <div class="col-sm">
    </div>
  </div>

  <br><br><br>

  @foreach($notifications as $notification)
  <div class="card">
      <div class="card-body">
          
        <p>Name : {{$notification->name}}</p>
        <p>Email : {{$notification->email}}</p>
        <p>Company: {{$notification->CompanyName}}</p>
        <p>Job desk : {{$notification->JobCategory}}</p>
        <p>Location : {{ $notification->region_id }}</p>
        <h6> <b> Status : {{$notification->status}} </b> </h6>
        <a href="{{url('notification_detail/ ' .$notification->id)}}">
          <button type="submit" value="Add" class="bttn-warning  bttn-jelly bttn-sm mt-5"  style ="width : 100px; height: 35px;">Detail</button>
        </a>
      </div>
  </div>
  <br>
  @endforeach

  @foreach($applys as $apply)
  <div class="card">
      <div class="card-body">
        <img src="{{ asset('images/JobsImage/' . $apply->Image) }}" class="card-img-top mr-5" style="height:250px; width:300px; align:left; float: left;">
        <p>Company: {{$apply->CompanyName}}</p>
        <p>Job desk : {{$apply->JobCategory}}</p>
        <button class="btn btn-secondary" style ="float : right; margin-top : 150px;"> Status : {{$apply->status}} </b> </button>
        <form action="{{url('Cancel/ ' .$apply->id)}}" method="post">
            @method('delete')
            @csrf
            <button class="btn btn-danger" style ="float : right; margin-top : 150px; margin-right : 5px"> cancel </b> </button>
        </form>
      </div>
  </div>
  <br>
  @endforeach

  @if(!is_null($messeges))
    @foreach($messeges as $messege)
    <div class="card">
      <div class="card-body">
        @foreach($jobs as $job)
        @if($job->id == $messege->Company_id)
        <img src="{{ asset('images/JobsImage/' . $job->Image) }}" class="card-img-top mr-5" style="height:250px; width:300px; align:left; float: left;">
          <p>Company: {{$job->CompanyName}}</p>
          <p> Interview Schedule : {{$messege->datetime}}</p>
          <p> Comment : {{$messege->comment}}</p>
        @endif
        @endforeach
        @if($messege->status == "Accepted")
          <button type="button" class="btn btn-success" style ="float : right; margin-top : 150px;">Status : {{$messege->status}} </button>
        @else
          <button class="btn btn-danger" style ="float : right; margin-top : 150px;"> Status : {{$messege->status}} </button>
        @endif
      </div>
    </div>
    <br>
  @endforeach
  @endif

  

</center>
</div>
@endsection
